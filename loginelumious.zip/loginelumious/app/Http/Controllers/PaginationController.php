<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class PaginationController extends Controller
{
    function fetch(Request $request)
    {
     if($request->ajax())
     {
      $data = DB::table('user_registers')->simplePaginate(5);
         return view('User.ajax_pagination', compact('data'))->render();
     }
    }
}
