<?php

namespace App\Http\Controllers;

use App\Models\UserRegister;
use Illuminate\Http\Request;

class UserRegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('User.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //  return $request->all();

        $request->validate([
            'user_name'    =>  'required',
            'user_about_me'     =>  'required',
			'user_date_of_birth'    =>  'required',
            'user_hobbies'     =>  'required'
        ]);
        if($request->hasFile('image')){
            $filename = $request->image->getClientOriginalName();
            $image_name = time().'_'.$filename; // Add current time before image name
            $request->image->storeAs('images',$image_name,'public');
            Auth()->user()->update(['image'=>$filename]);
        }
        $form_data = array(
            'user_name'       	=>   $request->user_name,
            'user_about_me'  =>   $request->user_about_me,
            'user_date_of_birth'  =>   $request->user_date_of_birth,
			'user_hobbies'        =>   implode(",", $request->user_hobbies),
            'image'         =>      $image_name
        );
        UserRegister::create($form_data);

        return redirect('dashboard')->with('success', 'User Data Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\UserRegister  $UserRegister
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $data = UserRegister::findOrFail($id);
        return view('User.view', compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\UserRegister  $UserRegister
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $data = UserRegister::findOrFail($id);
        //return $data;
        return view('User.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\UserRegister  $UserRegister
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id )
    {
        //

        $request->validate([
            'user_name'    =>  'required',
            'user_about_me'     =>  'required',
			'user_date_of_birth'    =>  'required',
            'user_hobbies'     =>  'required'
        ]);
        if($request->hasFile('image')){
            $filename = $request->image->getClientOriginalName();
            $image_name = time().'_'.$filename; // Add current time before image name
            $request->image->storeAs('images',$image_name,'public');
            Auth()->user()->update(['image'=>$filename]);
        }
        if($request->hasFile('image')){
            $form_data = array(
            'user_name'         =>   $request->user_name,
            'user_about_me'  =>   $request->user_about_me,
            'user_date_of_birth'  =>   $request->user_date_of_birth,
            'user_hobbies'        =>   implode(",", $request->user_hobbies),
            'image'         =>      $image_name
        );
        }
        else{
        
        $form_data = array(
            'user_name'         =>   $request->user_name,
            'user_about_me'  =>   $request->user_about_me,
            'user_date_of_birth'  =>   $request->user_date_of_birth,
            'user_hobbies'        =>   implode(",", $request->user_hobbies),
            );
        }
        UserRegister::whereId($id)->update($form_data);

        return redirect('dashboard')->with('success', 'User Data is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\UserRegister  $UserRegister
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data = UserRegister::findOrFail($id);
        $data->delete();

        return redirect('dashboard')->with('success', 'User Data is successfully deleted');
    }
}
