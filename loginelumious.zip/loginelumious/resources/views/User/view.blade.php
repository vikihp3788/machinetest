@extends('User.parent')

@section('main')
<h3 align="center">User Data List</h3>
<br />
<div class="jumbotron ">
	<div align="right">
		<a href="{{ url('dashboard') }}" class="btn btn-default">Back</a>
	</div>
	<h3>User Name - {{ $data->user_name }} </h3>
	<h3>User About Me - {{ $data->user_about_me }}</h3>
	<h3>User Date of Birth - {{ $data->user_date_of_birth }}</h3>
	<h3>User Hobbies - {!! $data->user_hobbies !!}</h3>
	<?php if($data->image!='') { ?>
		<h3> Profile Image </h3>
		<img src="{{ asset('public/storage/images/' . $data->image) }}" />
	<?php } ?>
@endsection
