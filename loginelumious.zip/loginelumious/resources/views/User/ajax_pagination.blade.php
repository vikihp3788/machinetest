@extends('User.parent')

@section('main')
<div class="col-md-11">
	<div class="table-responsive">
    	<table class="table table-bordered table-striped"  id="laravel">
		<tr>
			<th width="5%">User Id</th>
			<th width="10%">User Name</th>
			<th width="20%">User About Me</th>
			<th width="15%">User Date of Birth</th>
			<th width="15%">User Hobbies</th>
			<th width="10%">User Profile</th>
			<th width="20%">CRUD Opration</th>
		</tr>
		@foreach($data as $row)
		<tr>
			<td>{{ $row->id }}</td>
			<td>{{ $row->user_name }}</td>
			<td>{{ $row->user_about_me }}</td>
			<td>{{ $row->user_date_of_birth }}</td>
			<td>{{ $row->user_hobbies }}</td>
			<td><?php if($row->image!='') { ?>
				<img src="{{ asset('public/storage/images/' . $row->image) }}" width="70px" />
			<?php } ?>
			</td>
			<td>
				<form action="{{ route('user-register.destroy', $row->id) }}" method="post">
					<a href="{{ route('user-register.show', $row->id) }}" class="btn btn-primary">Show</a>
					<a href="{{ route('user-register.edit', $row->id) }}" class="btn btn-warning">Edit</a>
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-danger" onClick="return confirm('Are you sure you wish to delete this record?');">Delete</button>
				</form>
			</td>
		</tr>
		@endforeach
		{{ $data->links() }}
		</table>
	</div>
</div>
@endsection
