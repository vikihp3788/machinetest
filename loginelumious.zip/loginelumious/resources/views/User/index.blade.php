@extends('User.parent')

@section('main')
<h3 align="center">User Data List </h3>
<br />

<div align="right">
	<a href="{{ route('user-register.create') }}" class="btn btn-success btn-sm">Add</a>
</div>
<br />
@if ($message = Session::get('success'))
<div class="alert alert-success">
	<p>{{ $message }}</p>
</div>
@endif

<div id="table_data">
    @include('User.ajax_pagination')
</div>



@endsection
