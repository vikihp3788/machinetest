@extends('User.parent')

@section('main')
<h3 align="center">User List Data</h3>
<br />
@if($errors->any())
<div class="alert alert-danger">
	<ul>
		@foreach($errors->all() as $error)
		<li>{{ $error }}</li>
		@endforeach
	</ul>
</div>
@endif
<div align="right">
	<a href="{{ url('dashboard') }}" class="btn btn-default">Back</a>
</div>

	<form method="post" onSubmit="return validateUser()" action="{{ route('user-register.store') }}" enctype="multipart/form-data" id="user_form">
	{{ csrf_field() }}
		<div class="form-row">
			<div class="form-group col-md-6">
		  		<label for="inputEmail4">Enter User Name</label>
		  		<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter User Name" maxlength="30" onkeypress="return blockSpecialChar(event)">
			</div>

			<div class="form-group col-md-6">
		  		<label for="inputEmail4">Enter User Date of Birth</label>
		  		<input type="text" name="user_date_of_birth" id="user_date_of_birth" class="form-control" placeholder="Enter User Date of Birth" >
			</div>

            <div class="form-group col-md-12">
		  		<label for="inputEmail4">Enter User About Me</label>
                <textarea class="form-control" rows="5" name="user_about_me" id="user_about_me" minlength="10" maxlength="300"></textarea>
			</div>

            <div class="form-group col-md-12  " id="repeater">
                <div class="repeater-heading" >
                    <button type="button" class="btn btn-primary repeater-add-btn">Add More Hobbies</button>
                </div>
                <div class="clearfix"></div>
                <div class="items" data-group="programming_languages">
                    <div class="item-content">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-9">
                                    <label style="margin-top: 10px;">Enter User Hobbies</label>
                                    <input type="text" class="form-control" id="user_hobbies" placeholder="Enter User Hobbies"  data-skip-name="true" data-name=user_hobbies[]>
                                </div>
                                <div class="col-md-3" style="margin-top:24px;" align="center">
                                    <button id="remove-btn" class="btn btn-danger" onclick="$(this).parents('.items').remove()">Remove</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group col-md-12">
		  		<label for="inputEmail4">Enter User Profile Photo</label>
		  		<input type="file" name="image">
			</div>
	  	</div>
	  	<div class="form-group col-md-6">
			<button type="submit" class="btn btn-primary input-lg">Add User</button>
		</div>
	</form>
    <script src="{{url('resources/js/repeater.js')}}" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $("#repeater").createRepeater();
    });

    </script>

	<script type="text/javascript">
    function validateUser()
    {
		if(document.getElementById('user_name').value=='')
	   {
			alert("Please Enter User Name");

			document.getElementById('user_name').focus();
			return false;
		}

		if(document.getElementById('user_about_me').value=='')
	   	{
			alert("Please User About Me");

			document.getElementById('user_about_me').focus();
			return false;
		}

		if(document.getElementById('user_date_of_birth').value=='')
	   	{
			alert("Please Enter User Date of Birth");

			document.getElementById('user_date_of_birth').focus();
			return false;
        }

        if(document.getElementById('user_hobbies').value=='')
	   	{
			alert("Please Enter User Hobbies");

			document.getElementById('user_hobbies').focus();
			return false;
		}
		return true;
}
</script>

@endsection



