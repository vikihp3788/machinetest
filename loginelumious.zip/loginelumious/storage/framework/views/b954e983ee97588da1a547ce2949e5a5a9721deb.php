<?php $__env->startSection('main'); ?>
<div class="col-md-11">
	<div class="table-responsive">
    	<table class="table table-bordered table-striped"  id="laravel">
		<tr>
			<th width="5%">User Id</th>
			<th width="10%">User Name</th>
			<th width="20%">User About Me</th>
			<th width="15%">User Date of Birth</th>
			<th width="15%">User Hobbies</th>
			<th width="10%">User Profile</th>
			<th width="20%">CRUD Opration</th>
		</tr>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($row->id); ?></td>
			<td><?php echo e($row->user_name); ?></td>
			<td><?php echo e($row->user_about_me); ?></td>
			<td><?php echo e($row->user_date_of_birth); ?></td>
			<td><?php echo e($row->user_hobbies); ?></td>
			<td><?php if($row->image!='') { ?>
				<img src="<?php echo e(asset('public/storage/images/' . $row->image)); ?>" width="70px" />
			<?php } ?>
			</td>
			<td>
				<form action="<?php echo e(route('user-register.destroy', $row->id)); ?>" method="post">
					<a href="<?php echo e(route('user-register.show', $row->id)); ?>" class="btn btn-primary">Show</a>
					<a href="<?php echo e(route('user-register.edit', $row->id)); ?>" class="btn btn-warning">Edit</a>
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<button type="submit" class="btn btn-danger" onClick="return confirm('Are you sure you wish to delete this record?');">Delete</button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($data->links()); ?>

		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\loginelumious\resources\views/User/ajax_pagination.blade.php ENDPATH**/ ?>