<?php $__env->startSection('main'); ?>
<h3 align="center">User Data List </h3>
<br />

<div align="right">
	<a href="<?php echo e(route('user-register.create')); ?>" class="btn btn-success btn-sm">Add</a>
</div>
<br />
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
	<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<div id="table_data">
    <?php echo $__env->make('User.ajax_pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\loginelumious\resources\views/User/index.blade.php ENDPATH**/ ?>