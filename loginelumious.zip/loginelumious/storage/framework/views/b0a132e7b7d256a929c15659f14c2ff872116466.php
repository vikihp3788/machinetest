<?php $__env->startSection('main'); ?>
<h3 align="center">User Data List</h3>
<br />
<div align="right">
	<a href="<?php echo e(url('dashboard')); ?>" class="btn btn-default">Back</a>
</div>
<br />
<form method="post" onSubmit="return validateUser()" action="<?php echo e(route('user-register.update', $data->id)); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>
		<div class="form-row">
			<div class="form-group col-md-6">
		  		<label for="inputEmail4">Update User Name</label>
		  		<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter User Name" value="<?php echo e($data->user_name); ?>">
			</div>

			<div class="form-group col-md-6">
		  		<label for="inputEmail4">Update User Date of Birth</label>
		  		<input type="text" name="user_date_of_birth" id="user_date_of_birth" class="form-control" placeholder="Enter User Date of Birth" value="<?php echo e($data->user_date_of_birth); ?>">
			</div>
            <div class="form-group col-md-12  " id="repeater">
                
                <div class="clearfix"></div>
                <div class="items" data-group="programming_languages">
                    <div class="item-content">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Update User Hobbies</label>
                                    <?php $arrayOfFiles = explode(',',$data->user_hobbies); ;?>
                                    <?php $__currentLoopData = $arrayOfFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" class="form-control" placeholder="Enter User Hobbies"  data-skip-name="true" data-name=user_hobbies[] value="<?php echo $value; ?>" style="margin-bottom:15px">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group col-md-12">
		  		<label for="inputEmail4">Update User About Me</label>
                  <textarea class="form-control" rows="5" name="user_about_me" id="user_about_me" minlength="10" maxlength="300" placeholder="Enter User About Me"><?php echo e($data->user_about_me); ?></textarea>
			</div>
			<div class="form-group col-md-12">
				<label for="inputEmail4">Enter User Profile Photo</label>
				<?php if($data->image!='') { ?>
					<img src="<?php echo e(asset('public/storage/images/' . $data->image)); ?>" />
				<?php } else { ?>
					<p>No image found</p>
				<?php } ?>
			    <input type="file" name="image" class="form-control" value="<?php echo e($data->image); ?>"/>
		  		
			</div>
	  	</div>
	  	<div class="form-group col-md-6">
			<button type="submit" class="btn btn-primary input-lg">Update User</button>
		</div>
	</form>
    <script src="<?php echo e(url('resources/js/repeater.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $("#repeater").createRepeater();
    });

    </script>
    <script type="text/javascript">
    function validateUser()
    {
		if(document.getElementById('user_name').value=='')
	   {
			alert("Please Enter User Name");

			document.getElementById('user_name').focus();
			return false;
		}

		if(document.getElementById('user_about_me').value=='')
	   	{
			alert("Please User About Me");

			document.getElementById('user_about_me').focus();
			return false;
		}

		if(document.getElementById('user_date_of_birth').value=='')
	   	{
			alert("Please Enter User Date of Birth");

			document.getElementById('user_date_of_birth').focus();
			return false;
        }

        if(document.getElementById('user_hobbies').value=='')
	   	{
			alert("Please Enter User Hobbies");

			document.getElementById('user_hobbies').focus();
			return false;
		}
		return true;
    }
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('User.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\loginelumious\resources\views/User/edit.blade.php ENDPATH**/ ?>