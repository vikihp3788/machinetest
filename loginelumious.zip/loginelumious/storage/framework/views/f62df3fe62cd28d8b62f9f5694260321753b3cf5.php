<?php $__env->startSection('main'); ?>
<h3 align="center">User Data List</h3>
<br />
<div class="jumbotron ">
	<div align="right">
		<a href="<?php echo e(url('dashboard')); ?>" class="btn btn-default">Back</a>
	</div>
	<h3>User Name - <?php echo e($data->user_name); ?> </h3>
	<h3>User About Me - <?php echo e($data->user_about_me); ?></h3>
	<h3>User Date of Birth - <?php echo e($data->user_date_of_birth); ?></h3>
	<h3>User Hobbies - <?php echo $data->user_hobbies; ?></h3>
	<?php if($data->image!='') { ?>
		<h3> Profile Image </h3>
		<img src="<?php echo e(asset('public/storage/images/' . $data->image)); ?>" />
	<?php } ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\loginelumious\resources\views/User/view.blade.php ENDPATH**/ ?>