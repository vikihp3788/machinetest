<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>User Data List</title>
		<meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="<?php echo e(url('resources/js/repeater.js')); ?>" type="text/javascript"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
        <script>
        $( function() {
            $( "#user_date_of_birth" ).datepicker(
                {
                    minDate: new Date(1900,1-1,1), maxDate: '-18Y',
                    dateFormat: 'dd/mm/yy',
                    defaultDate: new Date(1970,1-1,1),
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '-110:-18'
                }
            );
        } );

        $(document).ready(function() {
            $(".js-example-tokenizer").select2({
                   tags: true,
                multiple: true,
                placeholder: 'Eg. Cricket',
                tokenSeparators: [',', ' '],
            })
        });
	  </script>

    <script type="text/javascript">
    function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
    </script>
	</head>
	<body>
		<div class="container">
  			<br />
  			<br />
  			<?php echo $__env->yieldContent('main'); ?>
  		</div>
	</body>
    <?php if(Auth::user()->image): ?>
<img class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">
<?php endif; ?>
</html>
<?php /**PATH E:\xampp\htdocs\loginelumious\resources\views/User/parent.blade.php ENDPATH**/ ?>